# 📋 Guia para Criar o Workflow no N8N

## Fluxo: Formulário → Banco de Dados → E-mail

### Step 1️⃣: Receber Dados do Formulário (Webhook)

1. No N8N, clique em **"+ Add Node"**
2. Procure por **"Webhook"**
3. Configure como:
   - **Method**: POST
   - **Authentication**: None (por enquanto)
   - **Path**: `/form-submit`

**Esperado receber JSON como:**
```json
{
  "nome": "João Silva",
  "email": "joao@example.com",
  "telefone": "11999999999",
  "mensagem": "Olá, gostaria de informações"
}
```

---

### Step 2️⃣: Processar/Validar Dados (Set)

1. Clique em **"+ Add Node"**
2. Escolha **"Set"** (ou "Edit Fields")
3. Configure os campos que serão salvos:
   - `nome`: `{{ $json.nome }}`
   - `email`: `{{ $json.email }}`
   - `telefone`: `{{ $json.telefone }}`
   - `mensagem`: `{{ $json.mensagem }}`
   - `data_submissao`: `{{ $now }}`

---

### Step 3️⃣: Salvar no Banco de Dados (PostgreSQL)

1. Clique em **"+ Add Node"**
2. Procure por **"PostgreSQL"**
3. Configure a conexão:
   - **Host**: `postgres`
   - **Port**: `5432`
   - **User**: `n8n_user`
   - **Password**: `n8n_password`
   - **Database**: `automacao_db`

4. Execute a query:
```sql
INSERT INTO formularios (nome, email, telefone, mensagem, status)
VALUES ($1, $2, $3, $4, 'novo')
RETURNING *;
```

**Mapear parâmetros:**
- `$1`: `{{ $json.nome }}`
- `$2`: `{{ $json.email }}`
- `$3`: `{{ $json.telefone }}`
- `$4`: `{{ $json.mensagem }}`

---

### Step 4️⃣: Enviar E-mail de Confirmação (SMTP)

1. Clique em **"+ Add Node"**
2. Procure por **"Send Email"** ou **"SMTP"**
3. Configure como:
   - **From**: seu_email@gmail.com
   - **To**: `{{ $json.email }}`
   - **Subject**: `Obrigado por entrar em contato!`
   - **HTML**: 

```html
<h2>Olá {{ $json.nome }},</h2>
<p>Recebemos sua mensagem com sucesso!</p>
<p><strong>Resumo do seu contato:</strong></p>
<ul>
  <li>Nome: {{ $json.nome }}</li>
  <li>Telefone: {{ $json.telefone }}</li>
  <li>Mensagem: {{ $json.mensagem }}</li>
</ul>
<p>Entraremos em contato em breve.</p>
<p>Atenciosamente,<br>Equipe de Automação</p>
```

---

### Step 5️⃣: Conectar os Nós

1. Clique na **seta de saída** do Webhook
2. Arraste até o nó **Set**
3. Clique na seta do **Set** e arraste até **PostgreSQL**
4. Clique na seta do **PostgreSQL** e arraste até **Send Email**

---

### Step 6️⃣: Testar o Workflow

1. Clique em **"Test Workflow"** (no canto inferior esquerdo)
2. Na aba do Webhook, clique em **"Copy URL"**
3. Use o **Postman** ou **curl** para testar:

```bash
curl -X POST http://localhost:5678/webhook/form-submit \
  -H "Content-Type: application/json" \
  -d '{
    "nome": "Teste Silva",
    "email": "teste@example.com",
    "telefone": "11998765432",
    "mensagem": "Mensagem de teste"
  }'
```

---

### Step 7️⃣: Salvar e Ativar

1. Clique em **"Save"** no canto superior
2. Dê um nome: `Formulário → Banco → Email`
3. Clique em **"Activate"** para ativar o workflow

---

## 🧪 Testes

### Teste Local com curl
```bash
# Windows PowerShell
$json = @{
    nome = "João"
    email = "joao@example.com"
    telefone = "11999999999"
    mensagem = "Teste"
} | ConvertTo-Json

Invoke-WebRequest -Uri "http://localhost:5678/webhook/form-submit" `
  -Method POST `
  -ContentType "application/json" `
  -Body $json
```

### Verificar Dados no Banco
```bash
docker-compose exec postgres psql -U n8n_user -d automacao_db -c "SELECT * FROM formularios;"
```

---

## 📝 Notas Importantes

- **Variáveis**: Use `{{ $json.campo }}` para acessar dados do JSON
- **Timestamps**: Use `{{ $now }}` para data/hora atual
- **Conexões**: Sempre teste a conexão antes de salvar
- **Ativação**: O workflow deve estar ATIVO (verde) para funcionar
- **Logs**: Verifique os logs em "Execution" para debug

---

## 🔐 Próximos Passos (Segurança)

1. Adicionar autenticação no Webhook (API Key)
2. Validar e-mails antes de salvar
3. Rate limiting
4. Logs de auditoria
5. Tratamento de erros

---

**Criado em**: 2026-06-15
