@echo off
REM Script para gerenciar os containers N8N (Windows)

setlocal enabledelayedexpansion

if "%1"=="start" (
    echo 🚀 Iniciando N8N...
    docker-compose up -d
    echo ✅ N8N iniciado em http://localhost:5678
    echo Usuário: admin
    echo Senha: admin123
) else if "%1"=="stop" (
    echo ⏹️  Parando N8N...
    docker-compose down
    echo ✅ N8N parado
) else if "%1"=="restart" (
    echo 🔄 Reiniciando N8N...
    docker-compose restart
    echo ✅ N8N reiniciado
) else if "%1"=="logs" (
    echo 📋 Logs N8N:
    docker-compose logs -f n8n
) else if "%1"=="logs-db" (
    echo 📋 Logs PostgreSQL:
    docker-compose logs -f postgres
) else if "%1"=="db" (
    echo 🗄️  Acessando PostgreSQL...
    docker-compose exec postgres psql -U n8n_user -d automacao_db
) else if "%1"=="db-reset" (
    echo ⚠️  Limpando banco de dados...
    docker-compose down -v
    docker-compose up -d
    echo ✅ Banco resetado
) else if "%1"=="status" (
    echo 📊 Status dos containers:
    docker-compose ps
) else (
    echo Uso: manage.bat {start^|stop^|restart^|logs^|logs-db^|db^|db-reset^|status}
    exit /b 1
)
