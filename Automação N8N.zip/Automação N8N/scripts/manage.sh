#!/bin/bash

# Script para gerenciar os containers N8N

set -e

# Cores para output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

case "$1" in
  start)
    echo -e "${BLUE}🚀 Iniciando N8N...${NC}"
    docker-compose up -d
    echo -e "${GREEN}✅ N8N iniciado em http://localhost:5678${NC}"
    ;;
  stop)
    echo -e "${BLUE}⏹️  Parando N8N...${NC}"
    docker-compose down
    echo -e "${GREEN}✅ N8N parado${NC}"
    ;;
  restart)
    echo -e "${BLUE}🔄 Reiniciando N8N...${NC}"
    docker-compose restart
    echo -e "${GREEN}✅ N8N reiniciado${NC}"
    ;;
  logs)
    echo -e "${BLUE}📋 Logs N8N:${NC}"
    docker-compose logs -f n8n
    ;;
  logs-db)
    echo -e "${BLUE}📋 Logs PostgreSQL:${NC}"
    docker-compose logs -f postgres
    ;;
  db)
    echo -e "${BLUE}🗄️  Acessando PostgreSQL...${NC}"
    docker-compose exec postgres psql -U n8n_user -d automacao_db
    ;;
  db-reset)
    echo -e "${RED}⚠️  Limpando banco de dados...${NC}"
    docker-compose down -v
    docker-compose up -d
    echo -e "${GREEN}✅ Banco resetado${NC}"
    ;;
  status)
    echo -e "${BLUE}📊 Status dos containers:${NC}"
    docker-compose ps
    ;;
  *)
    echo "Uso: ./scripts/manage.sh {start|stop|restart|logs|logs-db|db|db-reset|status}"
    exit 1
    ;;
esac
