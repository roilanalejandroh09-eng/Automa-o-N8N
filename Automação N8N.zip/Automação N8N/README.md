# 🤖 Automação com N8N

Projeto de automação usando **N8N** com um fluxo simples: **Formulário → Banco de Dados → E-mail**

## 📋 O que é N8N?

N8N é uma plataforma open-source para automação de workflows que permite conectar diferentes serviços e aplicações sem código ou com pouco código.

## 🏗️ Arquitetura do Projeto

```
Formulário (API/Webhook)
        ↓
    N8N Workflow
        ↓
  PostgreSQL (Armazenamento)
        ↓
  SMTP (Envio de E-mail)
```

## 📦 Serviços Utilizados

- **N8N**: Orquestrador de workflows
- **PostgreSQL**: Banco de dados para armazenar dados dos formulários
- **SMTP**: Serviço de envio de e-mails

## 🚀 Como Iniciar

### Pré-requisitos
- Docker e Docker Compose instalados
- Porta 5678 disponível (N8N)
- Porta 5432 disponível (PostgreSQL)

### Passos

1. **Clone ou navegue até o diretório do projeto**
```bash
cd "Automação N8N"
```

2. **Inicie os containers com Docker Compose**
```bash
docker-compose up -d
```

3. **Acesse a interface N8N**
```
http://localhost:5678
```

4. **Credenciais padrão**
- Usuário: `admin`
- Senha: `admin123`

## 📊 Próximos Passos

1. ✅ Criar um novo Workflow no N8N
2. ✅ Adicionar webhook para receber dados do formulário
3. ✅ Conectar ao PostgreSQL para salvar dados
4. ✅ Configurar SMTP para envio de e-mails
5. ✅ Testar o fluxo completo

## 🔧 Configurações Importantes

### Conexão com PostgreSQL
- Host: `postgres`
- Porta: `5432`
- Usuário: `n8n_user`
- Senha: `n8n_password`
- Banco: `automacao_db`

### Tabela de Formulários
```sql
formularios (
  id: INTEGER (PK),
  nome: VARCHAR,
  email: VARCHAR,
  telefone: VARCHAR,
  mensagem: TEXT,
  data_criacao: TIMESTAMP,
  status: VARCHAR
)
```

## 📞 Suporte

Para mais informações, consulte:
- [Documentação N8N](https://docs.n8n.io)
- [Documentação PostgreSQL](https://www.postgresql.org/docs/)

---
**Criado em**: 2026-06-15
