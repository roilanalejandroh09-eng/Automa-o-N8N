-- Criar tabela para armazenar dados do formulário
CREATE TABLE IF NOT EXISTS formularios (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    telefone VARCHAR(20),
    mensagem TEXT,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50) DEFAULT 'novo'
);

-- Criar índice para melhorar performance
CREATE INDEX idx_email ON formularios(email);
CREATE INDEX idx_data_criacao ON formularios(data_criacao);

-- Inserir um registro de exemplo
INSERT INTO formularios (nome, email, telefone, mensagem) 
VALUES ('Admin', 'admin@example.com', '11999999999', 'Teste inicial');
