# 🏗️ Arquitetura do Projeto

## 🔄 Fluxo Completo

```
┌─────────────────────────────────────────────────────────────────┐
│                          CLIENTE                                │
│                    (Formulário / API)                           │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
                    HTTP POST com JSON
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                          N8N                                     │
│                   Orquestrador de Workflow                       │
│                   (http://localhost:5678)                       │
│                                                                 │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐        │
│  │ Webhook  │→ │   Set    │→ │   Pg SQL │→ │   SMTP   │        │
│  │ (Recebe) │  │ (Processa)│ │ (Salva)  │  │ (Email)  │        │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘        │
│                                                                 │
└────┬───────────────────────────────┬─────────────────────┬──────┘
     │                               │                     │
     ▼                               ▼                     ▼
┌─────────────────┐      ┌──────────────────┐    ┌──────────────┐
│  PostgreSQL     │      │   SMTP Server    │    │  Gmail / SMTP│
│  (Banco Dados)  │      │  (Email Service) │    │  (Envio)     │
│                 │      │                  │    │              │
│ formularios     │      │ Credentials:     │    │ Configurar   │
│ - id            │      │ - host: smtp...  │    │ app password │
│ - nome          │      │ - port: 587      │    │              │
│ - email         │      │ - user: email    │    │ (Gmail)      │
│ - telefone      │      │ - pass: password │    │              │
│ - mensagem      │      │                  │    │              │
│ - data_criacao  │      │ Template HTML:   │    └──────────────┘
│ - status        │      │ - Confirmação    │
│                 │      │ - Dados recebidos│
│ (container)     │      │ - Link de acesso │
│ port: 5432      │      └──────────────────┘
│                 │
│ (container)     │
│ port: 5432      │
└─────────────────┘

```

---

## 🗂️ Estrutura de Diretórios

```
Automação N8N/
│
├── 🐳 Docker
│   ├── docker-compose.yml     ← Configuração de containers
│   └── init-db.sql            ← Script de inicialização do banco
│
├── 🚀 Início Rápido
│   ├── QUICKSTART.md          ← Comece aqui! (5 minutos)
│   ├── README.md              ← Documentação principal
│   └── WORKFLOW_GUIDE.md      ← Guia passo-a-passo para criar workflow
│
├── 📁 Scripts de Automação
│   ├── scripts/manage.sh      ← Gerenciador (Linux/Mac)
│   └── scripts/manage.bat     ← Gerenciador (Windows)
│
├── 📚 Documentação
│   ├── docs/TESTES.md         ← Exemplos de testes
│   ├── docs/SEGURANCA.md      ← Boas práticas
│   └── docs/TROUBLESHOOTING.md ← Resolução de problemas
│
├── 🔄 Workflows Exportados
│   └── workflows/README.md    ← Armazenar workflows JSON aqui
│
├── ⚙️ Configuração
│   ├── .env.example           ← Template de variáveis
│   ├── package.json           ← Scripts npm
│   └── .gitignore             ← Arquivos ignorados

```

---

## 🔌 Conexões e Integrações

### N8N Internal Flow
```
Event (Webhook POST)
    │
    ├─→ Parse JSON
    │
    ├─→ Validate Data
    │
    ├─→ Transform Data
    │
    ├─→ Save to DB (PostgreSQL)
    │
    ├─→ Send Email (SMTP)
    │
    └─→ Return Success/Error
```

### Network Diagram
```
┌────────────────────────────────────────┐
│         docker-compose network         │
│         "n8n-network" (bridge)         │
│                                        │
│  ┌──────────┐      ┌──────────────┐   │
│  │   N8N    │◄────►│ PostgreSQL   │   │
│  │:5678     │      │:5432         │   │
│  └──────────┘      └──────────────┘   │
│       │                                │
│       └───► SMTP (Gmail)               │
│            Internet                   │
│                                        │
└────────────────────────────────────────┘
```

---

## 📊 Estado dos Dados

### Workflow Execution States
```
PENDING
   │
   ├─→ RUNNING
   │      │
   │      ├─→ SUCCESS ✅
   │      │
   │      └─→ ERROR ❌
   │
   └─→ SKIPPED ⏭️
```

### Database Record States
```
novo
   │
   ├─→ processando
   │
   ├─→ sucesso (email enviado)
   │
   └─→ erro
```

---

## 🌐 URLs e Portas

```
┌─────────────────┬──────────────────────────────────────┐
│ Serviço         │ Endereço                             │
├─────────────────┼──────────────────────────────────────┤
│ N8N UI          │ http://localhost:5678                │
│ N8N API         │ http://localhost:5678/api            │
│ Webhook         │ http://localhost:5678/webhook/...    │
│ PostgreSQL      │ localhost:5432                       │
│ SMTP (externo)  │ smtp.gmail.com:587                   │
└─────────────────┴──────────────────────────────────────┘
```

---

## 🔐 Segurança - Camadas

```
┌────────────────────────────────────────┐
│     Cliente (seu navegador)            │
└────────────────────────────────────────┘
              │
              ▼ (HTTP/HTTPS)
┌────────────────────────────────────────┐
│  N8N (Autenticação básica)             │
│  admin:admin123                        │
└────────────────────────────────────────┘
              │
              ├──→ Webhook (sem auth por padrão)
              │
              ├──→ PostgreSQL (user/password)
              │
              └──→ SMTP (credentials)
```

---

## 🔄 Ciclo de Vida de um Registro

```
1. Cliente envia dados via webhook
        ↓
2. N8N recebe (Webhook node)
        ↓
3. N8N processa (Set node)
        ↓
4. N8N salva em PostgreSQL (SQL node)
        ├─→ INSERT na tabela "formularios"
        └─→ Retorna ID do registro
        ↓
5. N8N envia email (SMTP node)
        ├─→ To: email do formulário
        ├─→ Subject: Confirmação
        └─→ Body: HTML com dados
        ↓
6. N8N retorna sucesso ao cliente
        ↓
7. Log armazenado em N8N
        ↓
8. Dados visíveis em http://localhost:5678/workflow/executions
```

---

## 🔧 Dependências Externas

```
┌─────────────────┬──────────────┬───────────────┐
│ Serviço         │ Obrigatório  │ Alternativa   │
├─────────────────┼──────────────┼───────────────┤
│ N8N             │ ✅ Sim       │ -             │
│ PostgreSQL      │ ✅ Sim       │ SQLite        │
│ SMTP (Email)    │ ⚠️  Opcional │ Twilio, etc   │
│ Docker          │ ✅ Sim       │ Instalação Manual
└─────────────────┴──────────────┴───────────────┘
```

---

## 📈 Escalabilidade

### Expansão Possível
```
Versão 1 (Atual)
├─ Webhook → DB → Email
│
Versão 2 (Próximo)
├─ Múltiplos webhooks
├─ Validação avançada
├─ CRM integration
├─ Múltiplos emails
└─ Alerts/Notificações

Versão 3 (Futuro)
├─ Redis cache
├─ Load balancer
├─ Multiple N8N instances
├─ API Gateway
└─ Microserviços
```

---

**Criado em**: 2026-06-15
**Versão**: 1.0.0 - Inicial
