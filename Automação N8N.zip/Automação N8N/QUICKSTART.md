# 🚀 Quick Start - Guia de Início Rápido

## 📦 Estrutura do Projeto

```
Automação N8N/
├── docker-compose.yml          # Configuração dos containers
├── init-db.sql                 # Script de inicialização do banco
├── .env.example                # Variáveis de ambiente (exemplo)
├── .gitignore                  # Arquivos ignorados pelo Git
├── package.json                # Scripts npm
├── README.md                   # Documentação principal
├── WORKFLOW_GUIDE.md           # Guia para criar workflows
│
├── scripts/
│   ├── manage.sh               # Script de gerenciamento (Linux/Mac)
│   └── manage.bat              # Script de gerenciamento (Windows)
│
├── docs/
│   ├── TESTES.md               # Exemplos de testes (curl, PowerShell, Postman)
│   ├── SEGURANCA.md            # Boas práticas e segurança
│   └── TROUBLESHOOTING.md      # Resolução de problemas
│
└── workflows/
    └── README.md               # Informações sobre armazenamento de workflows
```

---

## ⚡ 5 Minutos para Começar

### 1️⃣ **Iniciar os Containers**

**Windows PowerShell:**
```powershell
# No diretório do projeto
.\scripts\manage.bat start
```

**Linux/Mac:**
```bash
chmod +x scripts/manage.sh
./scripts/manage.sh start
```

**Ou com Docker diretamente:**
```bash
docker-compose up -d
```

**Espere 30 segundos e acesse:**
```
http://localhost:5678
```

### 2️⃣ **Login**
- **Usuário:** `admin`
- **Senha:** `admin123`

### 3️⃣ **Criar Workflow**

Siga o [WORKFLOW_GUIDE.md](WORKFLOW_GUIDE.md) para criar o fluxo:

```
Webhook (Receber dados)
    ↓
Set (Processar)
    ↓
PostgreSQL (Salvar)
    ↓
SMTP (Enviar email)
```

### 4️⃣ **Testar**

**PowerShell:**
```powershell
$body = @{
    nome = "Seu Nome"
    email = "seu@email.com"
    telefone = "11999999999"
    mensagem = "Teste"
} | ConvertTo-Json

Invoke-WebRequest -Uri "http://localhost:5678/webhook/form-submit" `
  -Method POST `
  -ContentType "application/json" `
  -Body $body
```

### 5️⃣ **Verificar Resultados**

**Banco de dados:**
```bash
docker-compose exec postgres psql -U n8n_user -d automacao_db -c "SELECT * FROM formularios;"
```

ou

**Windows:**
```powershell
.\scripts\manage.bat db
```

---

## 📋 Checklist Rápido

- [ ] Docker e Docker Compose instalados
- [ ] Portas 5678 e 5432 disponíveis
- [ ] Containers iniciados com sucesso
- [ ] Acesso à UI N8N em http://localhost:5678
- [ ] Banco de dados criado
- [ ] Workflow criado e testado
- [ ] E-mail de teste enviado

---

## 🔗 Endpoints Importantes

| Serviço | URL |
|---------|-----|
| **N8N UI** | http://localhost:5678 |
| **N8N API** | http://localhost:5678/api |
| **Webhook** | http://localhost:5678/webhook/form-submit |
| **PostgreSQL** | localhost:5432 |

---

## 📚 Documentação Completa

1. **Começar:** [README.md](README.md)
2. **Criar Workflow:** [WORKFLOW_GUIDE.md](WORKFLOW_GUIDE.md)
3. **Testar:** [docs/TESTES.md](docs/TESTES.md)
4. **Segurança:** [docs/SEGURANCA.md](docs/SEGURANCA.md)
5. **Problemas:** [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md)

---

## 🎯 O que você terá ao final

✅ **Automação completa:**
1. Formulário recebe dados via webhook
2. N8N processa e valida
3. Dados salvos em PostgreSQL
4. E-mail enviado automaticamente

✅ **Infraestrutura:**
- N8N rodando
- PostgreSQL funcionando
- Database pronto para dados

✅ **Documentação:**
- Guias passo-a-passo
- Exemplos de testes
- Troubleshooting completo

---

## 🛑 Parar Tudo

**Windows:**
```powershell
.\scripts\manage.bat stop
```

**Linux/Mac:**
```bash
./scripts/manage.sh stop
```

**Ou:**
```bash
docker-compose down
```

---

## 🆘 Algum Problema?

Veja [docs/TROUBLESHOOTING.md](docs/TROUBLESHOOTING.md) para resolver:
- Container não inicia
- Porta em uso
- Conexão com banco falha
- E-mail não envia
- E muito mais...

---

**Pronto para começar? Vá para [WORKFLOW_GUIDE.md](WORKFLOW_GUIDE.md) →**

---

*Criado em: 2026-06-15*
*Versão: 1.0.0*
