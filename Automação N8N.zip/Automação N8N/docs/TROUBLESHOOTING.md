# 🚨 Troubleshooting

## Problemas Comuns e Soluções

### 1. **N8N não inicia**

**Erro:**
```
Error: connect ECONNREFUSED 127.0.0.1:5432
```

**Solução:**
```bash
# Verifi

que se o PostgreSQL está rodando
docker-compose ps

# Reinicie os containers
docker-compose down
docker-compose up -d
```

---

### 2. **Porta 5678 já está em uso**

**Erro:**
```
Bind for 0.0.0.0:5678 failed: port is already allocated
```

**Solução - Opção 1: Liberar a porta**
```bash
# Windows
netstat -ano | findstr :5678
taskkill /PID <PID> /F

# Linux/Mac
lsof -i :5678
kill -9 <PID>
```

**Solução - Opção 2: Mudar a porta**
```yaml
# docker-compose.yml
ports:
  - "5679:5678"  # Mude para 5679
```

---

### 3. **Webhook não recebe dados**

**Checklist:**
- ✅ Workflow está ATIVO (verde)?
- ✅ URL do webhook está correta?
- ✅ Método é POST?
- ✅ N8N está rodando (`docker-compose ps`)?

**Debug:**
```bash
# Veja os logs
docker-compose logs n8n

# Teste com curl
curl -X POST http://localhost:5678/webhook/form-submit \
  -H "Content-Type: application/json" \
  -d '{"nome":"Teste"}'
```

---

### 4. **Erro ao conectar ao PostgreSQL**

**Erro:**
```
FATAL: Ident authentication failed for user "n8n_user"
```

**Solução:**
```bash
# Verifique as credenciais em docker-compose.yml
# Resete o banco
docker-compose down -v
docker-compose up -d
```

---

### 5. **E-mail não é enviado**

**Checklist:**
- ✅ Credenciais SMTP corretas?
- ✅ App Password do Gmail gerado?
- ✅ 2FA ativado no Gmail?

**Teste de conexão SMTP:**
```bash
# Instale telnet ou use online tools
telnet smtp.gmail.com 587
```

**Solução:**
1. Gere App Password em https://myaccount.google.com/apppasswords
2. Use a senha gerada em N8N
3. Ative "Menos seguro" se necessário

---

### 6. **Dados não aparecem no banco**

**Verificar:**
```bash
# Acesse o banco
docker-compose exec postgres psql -U n8n_user -d automacao_db

# Liste as tabelas
\dt

# Veja os dados
SELECT * FROM formularios;
```

**Se tabela não existe:**
```bash
# Execute o SQL de inicialização
docker-compose exec postgres psql -U n8n_user -d automacao_db < init-db.sql
```

---

### 7. **Permissão negada ao acessar arquivos**

**Erro:**
```
permission denied: ./data/database.sqlite
```

**Solução:**
```bash
# Linux/Mac
chmod -R 755 ./data

# Windows (se necessário)
icacls .\data /grant Users:(OI)(CI)F /T
```

---

### 8. **Container crasheia ao iniciar**

**Debug:**
```bash
# Veja os logs detalhados
docker-compose logs --tail=100 n8n

# Reinicie e observe
docker-compose restart n8n
docker-compose logs -f n8n
```

**Causas comuns:**
- Falta de memória
- Porta em uso
- Arquivo corrompido

---

### 9. **N8N muito lento**

**Melhorias:**
```yaml
# docker-compose.yml
services:
  n8n:
    # Aumente memória
    mem_limit: 2g
    memswap_limit: 2g
    cpu_shares: 1024
```

---

### 10. **Como resetar tudo?**

```bash
# ⚠️ Isso apagará todos os dados!
docker-compose down -v
docker-compose up -d

# Ou apenas o banco
docker volume rm automacao_n8n_postgres_data
docker-compose up -d
```

---

## 📞 Logs Úteis

```bash
# Todos os logs
docker-compose logs

# Últimas 50 linhas
docker-compose logs --tail=50

# Apenas N8N, em tempo real
docker-compose logs -f n8n

# Apenas PostgreSQL
docker-compose logs postgres

# Com timestamps
docker-compose logs --timestamps
```

---

## 🆘 Quando nada funciona

```bash
# Limpe tudo
docker-compose down -v
docker system prune -a

# Reconstrua
docker-compose build --no-cache
docker-compose up -d

# Verifique status
docker-compose ps
```

---

**Criado em**: 2026-06-15
**Última atualização**: 2026-06-15
