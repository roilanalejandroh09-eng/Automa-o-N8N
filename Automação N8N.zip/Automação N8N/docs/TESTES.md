# Exemplo de teste do Webhook com curl/PowerShell

## 📌 Teste com curl (Command Line)

```bash
curl -X POST http://localhost:5678/webhook/form-submit \
  -H "Content-Type: application/json" \
  -d '{
    "nome": "Teste Silva",
    "email": "teste@example.com",
    "telefone": "11998765432",
    "mensagem": "Esta é uma mensagem de teste"
  }'
```

---

## 📌 Teste com PowerShell (Windows)

### Método 1: Invoke-WebRequest

```powershell
$body = @{
    nome = "João Santos"
    email = "joao@example.com"
    telefone = "11999999999"
    mensagem = "Testando a automação N8N"
} | ConvertTo-Json

Invoke-WebRequest -Uri "http://localhost:5678/webhook/form-submit" `
  -Method POST `
  -ContentType "application/json" `
  -Body $body
```

### Método 2: Com múltiplos testes

```powershell
# Teste 1
$test1 = @{
    nome = "Maria Silva"
    email = "maria@example.com"
    telefone = "11987654321"
    mensagem = "Primeiro contato"
} | ConvertTo-Json

Invoke-WebRequest -Uri "http://localhost:5678/webhook/form-submit" `
  -Method POST `
  -ContentType "application/json" `
  -Body $test1

Write-Host "✅ Teste 1 enviado"

# Teste 2
$test2 = @{
    nome = "Carlos Mendes"
    email = "carlos@example.com"
    telefone = "11998765432"
    mensagem = "Segundo contato"
} | ConvertTo-Json

Invoke-WebRequest -Uri "http://localhost:5678/webhook/form-submit" `
  -Method POST `
  -ContentType "application/json" `
  -Body $test2

Write-Host "✅ Teste 2 enviado"
```

---

## 📌 Teste com Postman

1. **Criar novo Request**
   - Method: POST
   - URL: `http://localhost:5678/webhook/form-submit`

2. **Headers**
   - Content-Type: `application/json`

3. **Body (raw, JSON)**
```json
{
  "nome": "Pedro Costa",
  "email": "pedro@example.com",
  "telefone": "11988888888",
  "mensagem": "Teste via Postman"
}
```

4. **Enviar**

---

## 📌 Verificar Resultados

### 1. Checar banco de dados

```bash
docker-compose exec postgres psql -U n8n_user -d automacao_db -c "SELECT * FROM formularios ORDER BY data_criacao DESC;"
```

### 2. Checar logs do N8N

```bash
docker-compose logs n8n --tail=50
```

### 3. Verificar na UI do N8N

- Acesse: http://localhost:5678
- Abra o workflow
- Clique em "Executions"
- Veja o histórico de execuções

---

## 🧪 Teste de Validação

Após enviar os testes, confirme:

- ✅ Webhook recebeu os dados
- ✅ Dados foram salvos no PostgreSQL
- ✅ E-mail foi enviado (verificar logs)
- ✅ Status "novo" no banco de dados

---

**Criado em**: 2026-06-15
