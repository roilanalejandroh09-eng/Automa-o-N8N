# 🔒 Segurança e Boas Práticas

## ⚠️ Cuidados Importantes

### 1. **Credenciais**
- ❌ Nunca compartilhe credenciais em repositórios
- ✅ Use variáveis de ambiente (`.env`)
- ✅ Adicione `.env` ao `.gitignore`

### 2. **Webhook Security**
```bash
# Adicione autenticação ao webhook
# No N8N: Webhook → Authentication → API Key
```

### 3. **Senhas Padrão**
```
ANTES de colocar em produção:
- Altere admin/admin123
- Configure certificados SSL
- Use HTTPS em vez de HTTP
```

### 4. **Banco de Dados**
```sql
-- Criar usuário com permissões limitadas
CREATE USER app_user WITH PASSWORD 'senha_forte';
GRANT SELECT, INSERT ON formularios TO app_user;
```

## 🛡️ Configurações de Produção

### 1. Variáveis de Ambiente
```env
# .env (produção)
N8N_BASIC_AUTH_PASSWORD=senhaforte123456
DATABASE_TYPE=postgres
DB_POSTGRES_HOST=db.production.com
DB_POSTGRES_USER=prod_user
DB_POSTGRES_PASSWORD=senhaforte789
```

### 2. Certificado SSL
```yaml
# docker-compose.yml
environment:
  - N8N_PROTOCOL=https
  - N8N_SSL_KEY=/home/node/.n8n/ssl/key.pem
  - N8N_SSL_CERT=/home/node/.n8n/ssl/cert.pem
```

### 3. Rate Limiting
Configure no nginx ou firewall:
```
Max requests: 100/hora por IP
```

## 📋 Checklist de Segurança

- [ ] Alterar senhas padrão
- [ ] Configurar HTTPS/SSL
- [ ] Habilitar autenticação em webhooks
- [ ] Configurar backup automático do banco
- [ ] Adicionar validação de entrada
- [ ] Implementar logging de eventos
- [ ] Configurar alertas de erro
- [ ] Testes de penetração

## 🔄 Backup e Recuperação

### Backup do Banco
```bash
docker-compose exec postgres pg_dump -U n8n_user automacao_db > backup.sql
```

### Restaurar do Backup
```bash
docker-compose exec -T postgres psql -U n8n_user automacao_db < backup.sql
```

### Backup de Workflows
1. No N8N: Download de cada workflow
2. Commit no Git
3. Armazene em local seguro

---

**Criado em**: 2026-06-15
