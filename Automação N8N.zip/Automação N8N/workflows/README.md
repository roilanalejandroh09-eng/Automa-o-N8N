# Estrutura de Workflows

Este diretório armazena os arquivos de workflows exportados do N8N.

## 📁 Organização

- `formulario-para-email/` - Workflow: Formulário → Email
- `formulario-para-banco/` - Workflow: Formulário → Banco de Dados
- `completo/` - Workflow completo: Formulário → Banco → Email

## 📤 Como Exportar um Workflow

1. No N8N, clique no workflow
2. Menu (três pontos) → **Download**
3. Salve o arquivo `.json` neste diretório

## 📥 Como Importar um Workflow

1. No N8N, clique em **"+ New Workflow"**
2. Menu → **Import**
3. Selecione o arquivo `.json`

## 🔄 Versionamento

Mantenha histórico dos workflows importantes:

```
workflows/
├── v1_basico.json
├── v2_com_validacao.json
└── v3_com_tratamento_erros.json
```
